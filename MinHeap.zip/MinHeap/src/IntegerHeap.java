public class IntegerHeap implements TaDHeap<Integer> {

	private int max;
	private int ultimo;
	private int size;
	private int[] vector;
	private static final int FRONT = 1;

	public IntegerHeap(int h) {
		this.ultimo = 0;
		this.size = 0;
		vector = new int[this.max + 1];
		vector[0] = Integer.MIN_VALUE;

	}

	public void inserir(Integer obj) {

		if (ultimo <= max - 1) {
			vector[ultimo] = obj;
			corrigeAcima(obj);
			ultimo += 1;
		} else {
			System.out.println("Heap cheio!");
		}
	}

	private void corrigeAcima(int posi��o) {
		while (posi��o > 0) {
			int pai = (posi��o - 1) / 2;
			if (vector[pai] > vector[posi��o]) {
				troca(posi��o, pai);
			} else {
				break;
			}
			posi��o = pai;
		}
	}

	private void troca(int posi��o, int pai) {
		int aux = vector[pai];
		vector[pai] = vector[posi��o];
		vector[posi��o] = aux;
	}

	public Integer remover() {
		int rev = vector[FRONT];
		vector[FRONT] = vector[size--];
		corrigeAcima(FRONT);
		return rev;
	}

	public void imprimir() {
      for(int i = 0; i <= size / 2; i++){
    	  System.out.println("Pai: " + vector[i] + "Filho esquerda: "
					+ vector[2 * i] + "Filho direita: " + vector[2 * i + 1]);
      }
	}

	public void imprimirIdentado() {

	}

}
