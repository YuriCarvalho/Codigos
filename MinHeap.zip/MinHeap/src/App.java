
public class App {

	public static void main(String[] args) {
	   
		System.out.println("Min �: ");
		TaDHeap heap = new IntegerHeap(5);
		heap.inserir(4);
		heap.inserir(7);
		heap.inserir(5);
		heap.inserir(3);
		heap.inserir(4);
		heap.inserir(22);
		
		heap.imprimir();
		System.out.println("Min: " + heap.remover());

	}

}
