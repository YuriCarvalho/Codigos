public interface TaDHeap<T> {
	public void inserir(T obj);

	public T remover();

	public void imprimir();

	public void imprimirIdentado();
}
