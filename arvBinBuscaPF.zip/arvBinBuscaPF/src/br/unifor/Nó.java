package br.unifor;

public class N� {

	private Aluno aluno;
	private N� pai;
	private N� sae;
	private N� sad;

	public N�(Aluno aluno) {
		this.aluno = aluno;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public Aluno setAluno(Aluno aluno) {
		return this.aluno = aluno;
	}

	public N� getPai() {
		return pai;
	}

	public void setPai(N� pai) {
		this.pai = pai;
	}

	public N� getSae() {
		return sae;
	}

	public void setSae(N� sae) {
		this.sae = sae;
	}

	public N� getSad() {
		return sad;
	}

	public void setSad(N� sad) {
		this.sad = sad;
	}

}
