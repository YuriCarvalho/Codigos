package br.unifor;

public interface Arvore {

	public void adicionarN�Recursivo(Aluno aluno);

	public void adicionarN�Iterativo(Aluno aluno);

	public void removerN�(Aluno aluno);

	public void imprimirPreOrder();

	public void imprimirPostOrder();

	public void imprimirPreIn();
}
