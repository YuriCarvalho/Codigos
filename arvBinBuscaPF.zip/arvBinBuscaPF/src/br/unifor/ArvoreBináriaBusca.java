package br.unifor;

public class ArvoreBin�riaBusca implements Arvore {

	private N� raiz;

	public ArvoreBin�riaBusca() {
		this.raiz = null;
	}

	public void adicionarN�Recursivo(Aluno aluno) {

		N� n� = new N�(aluno);
		adicionarN�Recursivo(n�, raiz);
	}

	private void adicionarN�Recursivo(N� n�, N� raiz) {

		if (raiz == null) {
			raiz = n�;
		} else if (n�.getAluno().getMatricula() < raiz.getAluno().getMatricula()) {
			if (raiz.getSae() != null) {
				raiz.setSae(n�);

			} else {
				adicionarN�Recursivo(n�, raiz.getSae());
			}
		} else if (n�.getAluno().getMatricula() < raiz.getAluno().getMatricula()) {
			if (raiz.getSad() != null) {
				raiz.setSad(n�);

			} else {
				adicionarN�Recursivo(n�, raiz.getSad());
			}

		} else {
			raiz = n�;

		}
	}

	public void adicionarN�Iterativo(Aluno aluno) {

	}

	public void removerN�(Aluno aluno) {

	}

	public void imprimirPreOrder() {

	}

	public void imprimirPostOrder() {

	}

	public void imprimirPreIn() {

	}

}
