public class App {

	public static void main(String[] args) {
		System.out.println("Max Heap �: ");
		TaDHeap heap = new IntegerHeap(5);
		heap.inserir(11);
		heap.inserir(8);
		heap.inserir(5);
		heap.inserir(3);
		heap.inserir(4);
		heap.inserir(15);
		
		heap.imprimir();
		System.out.println("Max: " + heap.remover());
	}

}
