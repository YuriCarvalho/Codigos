package br.unifor;

public interface Arvore {

	public void adicionarN�Recursivo(Aluno aluno);

	public void adicionarN�Interativo(Aluno aluno);

	public void removerN�(Aluno aluno);

	public void imprimirPreOrder();

	public void imprimirPostOrder();

	public void imprimirInOrder();

	private void rotacaoDireita(N� r);

	private void rotacaoEsquerda(N� r);

	private void rotacaoDireitaEsquerda(N� r);

	private void rotacaoEsquerdaDireita(N� r);
}
