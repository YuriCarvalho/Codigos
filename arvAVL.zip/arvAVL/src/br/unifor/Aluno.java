package br.unifor;

public class Aluno {
	
	private long matricula;
	private String nome;
	private String email;
	
	public Aluno(long matricula, String nome, String email) {
		this.matricula = matricula;
		this.nome = nome;
		this.email = email;
			
	}
}

	