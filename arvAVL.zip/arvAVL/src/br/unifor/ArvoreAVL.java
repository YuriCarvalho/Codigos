package br.unifor;

public class ArvoreAVL implements Arvore {

	private N� raiz;

	public ArvoreAVL(N� raiz) {
		this.raiz = raiz;
	}

	@Override
	public void adicionarN�Recursivo(Aluno aluno) {
		// TODO Auto-generated method stub

	}

	@Override
	public void adicionarN�Interativo(Aluno aluno) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removerN�(Aluno aluno) {
		// TODO Auto-generated method stub

	}

	@Override
	public void imprimirPreOrder() {
		// TODO Auto-generated method stub

	}

	@Override
	public void imprimirPostOrder() {
		// TODO Auto-generated method stub

	}

	@Override
	public void imprimirInOrder() {
		// TODO Auto-generated method stub

	}

	private void rotacaoDireita(N� r) {

		N� pai = r.getPai();
		N� t = r.getSae();
		N� m = t.getSad();

		t.setSad(r);
		r.setPai(t);

		r.setSad(m);
		if (m != null)
			m.setPai(r);

		t.setPai(pai);

		if (pai.getSad() == r)
			pai.setSad(t);
		else
			pai.setSae(t);

		t.setFatorBalanceamento(0);
		r.setFatorBalanceamento(0);

	}

	private void rotacaoEsquerda(N� r) {
		
		N� pai = r.getPai();
		N� t = r.getSae();
		N� m = t.getSad();

		t.setSad(r);
		r.setPai(t);

		r.setSad(m);
		if (m != null)
			m.setPai(r);

		t.setPai(pai);

		if (pai.getSad() == r)
			pai.setSad(t);
		else
			pai.setSae(t);

		t.setFatorBalanceamento(0);
		r.setFatorBalanceamento(0);

	}

	private void rotacaoDireitaEsquerda(N� r) {

	}

	private void rotacaoEsquerdaDireita(N� r) {

	}

}
